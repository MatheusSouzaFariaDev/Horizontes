

(function () {
  'use strict';

  const PHOTOS = [
    { src: 'images/fotos/foto1.jpeg',  title: 'Guindaste e Itu visto da Fatec',   category: 'fatec' },
    { src: 'images/fotos/foto2.jpeg',  title: 'Guindaste no pôr do sol', category: 'fatec' },
    { src: 'images/fotos/foto3.jpeg',  title: 'Sol visto através do maquinário pesado', category: 'fatec' },
    { src: 'images/fotos/foto4.jpeg',  title: 'Destaque do maquinário pesado', category: 'fatec' },
    { src: 'images/fotos/foto5.jpeg',  title: 'Despedida do sol vista do campo',       category: 'por-do-sol' },
    { src: 'images/fotos/foto6.jpeg',  title: 'Vista ampla do sol sumindo',     category: 'por-do-sol' },
    { src: 'images/fotos/foto7.jpeg',  title: 'Corrimão recebendo luz ao entardecer',     category: 'por-do-sol' },
    { src: 'images/fotos/foto8.jpeg',  title: 'Natureza e seu esforço',     category: 'por-do-sol' },
    { src: 'images/fotos/foto9.jpeg',  title: 'Natureza e sua recompensa',     category: 'por-do-sol' },
    { src: 'images/fotos/foto10.jpeg', title: 'Caminho do estacionamento',     category: 'por-do-sol' },
    { src: 'images/fotos/foto11.jpeg', title: 'Caixa da água',     category: 'por-do-sol' },
    { src: 'images/fotos/foto12.jpeg', title: '(OBTNI) Objeto Terrestre Não-Identificado',     category: 'por-do-sol' },
    { src: 'images/fotos/foto13.jpeg', title: 'Supernova capturada em câmera',     category: 'por-do-sol' },
    { src: 'images/fotos/foto14.jpeg', title: 'Últimos momentos de dois estudantes antes da Supernova',    category: 'por-do-sol' },
    { src: 'images/fotos/foto15.jpeg', title: 'Caixa da água (coube na câmera dessa vez)',    category: 'por-do-sol' },
    { src: 'images/fotos/foto16.jpeg', title: 'Supernova foi humilde e deixou um sobrevivente',    category: 'por-do-sol' },
    { src: 'images/fotos/foto17.jpeg', title: 'Cavalinho de Pau kk (olha essa geometria)',    category: 'por-do-sol' },
    { src: 'images/fotos/foto18.jpeg', title: 'Welcome To The Jungle',    category: 'por-do-sol' },
    { src: 'images/fotos/foto19.jpeg', title: 'Gradiente solar',    category: 'por-do-sol' },
    { src: 'images/fotos/foto20.jpeg', title: 'Mosquito fazendo pose',    category: 'por-do-sol' }
  ];

  window.PHOTOS = PHOTOS;

  const THEME_KEY = 'fatec-portfolio-theme';
  const root = document.documentElement;
  const stored = localStorage.getItem(THEME_KEY);
  if (stored === 'dark' || (!stored && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    root.setAttribute('data-theme', 'dark');
  }

  function bindThemeToggle() {
    const btn = document.querySelector('[data-theme-toggle]');
    if (!btn) return;
    const update = () => {
      const isDark = root.getAttribute('data-theme') === 'dark';
      btn.setAttribute('aria-pressed', String(isDark));
      btn.setAttribute('aria-label', isDark ? 'Ativar modo claro' : 'Ativar modo escuro');
    };
    update();
    btn.addEventListener('click', () => {
      const isDark = root.getAttribute('data-theme') === 'dark';
      if (isDark) { root.removeAttribute('data-theme'); localStorage.setItem(THEME_KEY, 'light'); }
      else        { root.setAttribute('data-theme', 'dark'); localStorage.setItem(THEME_KEY, 'dark'); }
      update();
    });
  }

  function bindNav() {
    const nav = document.querySelector('.nav');
    const toggle = document.querySelector('[data-nav-toggle]');
    const links = document.querySelector('[data-nav-links]');
    if (nav) {
      const onScroll = () => nav.classList.toggle('is-scrolled', window.scrollY > 8);
      onScroll();
      window.addEventListener('scroll', onScroll, { passive: true });
    }
    if (toggle && links) {
      toggle.addEventListener('click', () => {
        const open = links.classList.toggle('is-open');
        toggle.setAttribute('aria-expanded', String(open));
      });
      links.querySelectorAll('a').forEach(a =>
        a.addEventListener('click', () => {
          links.classList.remove('is-open');
          toggle.setAttribute('aria-expanded', 'false');
        })
      );
    }
  }

  function bindReveal() {
    const els = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window) || !els.length) {
      els.forEach(el => el.classList.add('is-visible'));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('is-visible');
          io.unobserve(e.target);
        }
      });
    }, { threshold: .12, rootMargin: '0px 0px -40px 0px' });
    els.forEach(el => io.observe(el));
  }

  
  function setYear() {
    const y = document.querySelector('[data-year]');
    if (y) y.textContent = new Date().getFullYear();
  }

  
  function buildGallery() {
    const container = document.querySelector('[data-gallery]');
    if (!container) return;
    container.innerHTML = PHOTOS.map((p, i) => `
      <figure data-index="${i}" data-category="${p.category}">
        <img src="${p.src}" alt="${p.title} — fotografia ambiental na Fatec Itu" loading="lazy" decoding="async">
        <figcaption>
          <span>${p.title}</span>
          <small>${p.category === 'por-do-sol' ? 'Pôr do sol' : 'Fatec'}</small>
        </figcaption>
      </figure>
    `).join('');

    container.addEventListener('click', (e) => {
      const fig = e.target.closest('figure');
      if (!fig) return;
      const idx = Number(fig.dataset.index);
      openLightbox(idx);
    });

    // Filtros
    const chips = document.querySelectorAll('[data-filter]');
    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        chips.forEach(c => c.setAttribute('aria-pressed', 'false'));
        chip.setAttribute('aria-pressed', 'true');
        const f = chip.dataset.filter;
        container.querySelectorAll('figure').forEach(fig => {
          const match = f === 'all' || fig.dataset.category === f;
          fig.classList.toggle('is-hidden', !match);
        });
      });
    });
  }

  function buildFeatured() {
    const grid = document.querySelector('[data-featured]');
    if (!grid) return;
    const picks = [PHOTOS[3], PHOTOS[0], PHOTOS[7], PHOTOS[10], PHOTOS[13], PHOTOS[15]].filter(Boolean);
    grid.innerHTML = picks.map((p, i) => {
      const realIndex = PHOTOS.indexOf(p);
      return `
        <figure data-index="${realIndex}">
          <img src="${p.src}" alt="${p.title}" loading="${i < 2 ? 'eager' : 'lazy'}" decoding="async">
          <figcaption>${p.title}</figcaption>
        </figure>
      `;
    }).join('');
    grid.addEventListener('click', (e) => {
      const fig = e.target.closest('figure');
      if (!fig) return;
      openLightbox(Number(fig.dataset.index));
    });
  }

  let lbCurrent = 0;
  let lbVisible = [];   
  let lastFocus = null;

  function getVisibleIndexes() {
    const container = document.querySelector('[data-gallery]');
    if (!container) return PHOTOS.map((_, i) => i);
    return [...container.querySelectorAll('figure')]
      .filter(f => !f.classList.contains('is-hidden'))
      .map(f => Number(f.dataset.index));
  }

  function openLightbox(index) {
    const lb = document.querySelector('[data-lightbox]');
    if (!lb) return;
    lastFocus = document.activeElement;
    lbVisible = getVisibleIndexes();
    if (!lbVisible.includes(index)) lbVisible = PHOTOS.map((_, i) => i);
    lbCurrent = lbVisible.indexOf(index);
    if (lbCurrent < 0) lbCurrent = 0;
    renderLightbox();
    lb.classList.add('is-open');
    lb.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    lb.querySelector('.lightbox__close')?.focus();
  }
  function closeLightbox() {
    const lb = document.querySelector('[data-lightbox]');
    if (!lb) return;
    lb.classList.remove('is-open');
    lb.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (lastFocus) lastFocus.focus();
  }
  function step(delta) {
    lbCurrent = (lbCurrent + delta + lbVisible.length) % lbVisible.length;
    renderLightbox();
  }
  function renderLightbox() {
    const lb = document.querySelector('[data-lightbox]');
    if (!lb) return;
    const photo = PHOTOS[lbVisible[lbCurrent]];
    if (!photo) return;
    const img = lb.querySelector('img');
    const cap = lb.querySelector('.lightbox__caption');
    const counter = lb.querySelector('.lightbox__counter');
    img.src = photo.src;
    img.alt = photo.title;
    cap.textContent = photo.title;
    counter.textContent = `${lbCurrent + 1} / ${lbVisible.length}`;
  }
  function bindLightbox() {
    const lb = document.querySelector('[data-lightbox]');
    if (!lb) return;
    lb.querySelector('.lightbox__close').addEventListener('click', closeLightbox);
    lb.querySelector('.lightbox__btn--prev').addEventListener('click', () => step(-1));
    lb.querySelector('.lightbox__btn--next').addEventListener('click', () => step(1));
    lb.addEventListener('click', (e) => { if (e.target === lb) closeLightbox(); });
    document.addEventListener('keydown', (e) => {
      if (!lb.classList.contains('is-open')) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') step(1);
      if (e.key === 'ArrowLeft') step(-1);
    });
  }

  
  document.addEventListener('DOMContentLoaded', () => {
    bindThemeToggle();
    bindNav();
    buildFeatured();
    buildGallery();
    bindLightbox();
    bindReveal();
    setYear();
  });
})();
